Ce fichier a pour objectif d’aider à comprendre les GRAFCETs du projet du robot pick and place. Il sert de guide de lecture et précise les documents nécessaires pour appréhender correctement la logique de commande du système.

1- Le rapport(1.Partie électronique et électrique)
	C'est le document central pour la compréhension de la commande séquentielle. Il présente les GRAFCETs un par un et explique leur rôle, ainsi que GEMMA et Structure H du système 

2- Schéma pneumatique 

	Ce document décrit le fonctionnement des actionneurs pneumatiques (vérins et pince) ainsi que leur mode de pilotage.
Il est indispensable pour comprendre les actions et les transitions indiquées dans les GRAFCETs, notamment celles liées aux mouvements verticaux et à la prise des pièces.

3-Liste des variables
	
Ce document regroupe l’ensemble des variables utilisées dans la commande du système (modes de marche, capteurs, actionneurs, positions et compteurs).
Il permet de comprendre les conditions de transition et les actions associées aux différentes étapes des Grafcets. 