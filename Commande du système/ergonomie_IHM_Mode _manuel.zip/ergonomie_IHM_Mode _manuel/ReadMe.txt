 IHM Robot – Mode Manuel

Cette interface -IHM est associée au mode manuel du robot.  
Il s’agit d’une ergonomie IHM de conception et de visualisation, et non d’une IHM réellement implémentée sur un automate du projet.

Cette interface a pour objectif de proposer une organisation ergonomique et une vision globale des commandes nécessaires au fonctionnement du robot en mode manuel.  
Elle permet de regrouper toutes les commandes sur un seul écran, afin de faciliter l’utilisation par l’opérateur.

L’IHM intègre :
- Les commandes de déplacement du robot selon les axes X et Y
- La commande manuelle du vérin
- La commande d’ouverture et de fermeture de la pince
- L’affichage de la position du robot et une zone de visualisation

Cette IHM constitue donc une **proposition d’amélioration du fonctionnement en mode manuel** et un support de réflexion pour une future implémentation sur automate ou système embarqué.
